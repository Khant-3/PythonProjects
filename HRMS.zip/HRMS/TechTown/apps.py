from django.apps import AppConfig


class TechtownConfig(AppConfig):
    name = 'TechTown'
